'''
--------------------- PROJET 1 - CHESS ---------------------

Bandeau d'informations - tenir à jour !

Version : 2.3

Dernière édition : Victor, 05/10 08:06

Commentaire :
    - Déplacements basiques de toutes les pièces
    - Fonction check_line(case : str, addx : int, addy : int) -> list qui donne la liste des cases en ajoutant constament addx et addy jusqu'aux bords
    - Déplacements des tours, fous et dames jusqu'au bords ou jusqu'à d'autres pièces, inclues si de couleur opposée, en utilisant check_line()
    - Améliorations de la visibilité du code
    - Pareil pour les cavaliers et les rois
    - Déplacements des pions jusqu'aux pièces dans le passage
    - Plus que les prises des pions !

Précédente édition : Victor, 04/10 15:03

-------------------- positions_possibles.py ----------------
'''




position = [["tn", "cn", "fn", "dn", "rn", "fn", "cn", "tn"],
            ["pn", "pn", "pn", "pn", "pn", "pn", "pn", "pn"],
            [".", ".", ".", "db", ".", ".", ".", ".", ],
            [".", ".", "pb", ".", ".", ".", ".", ".", ],
            [".", ".", ".", ".", ".", ".", ".", ".", ],
            [".", ".", ".", ".", ".", ".", ".", ".", ],
            ["pb", "pb", "pb", "pb", "pb", "pb", "pb", "pb"],
            ["tb", "cb", "fb", "db", "rb", "fb", "cb", "tb"]]



# get_place() et get_piece() sont les même que dans main.py

coordinates = [["a", "b", "c", "d", "e", "f", "g", "h"], ["8", "7", "6", "5", "4", "3", "2", "1"]]

def get_place(case : str) -> (int, int):
    place = (coordinates[0].index(case[0]), coordinates[1].index(case[1]))
    return place



def get_piece(case : str) -> str :
    piece = position[get_place(case)[1]][get_place(case)[0]]
    return piece





# Cette fonction renvoie toutes les cases en ajoutant addx et addy à chaque case jusqu'au bord (list)

def check_line(case : str, addx : int, addy : int) -> list :
    
    piece = get_piece(case)
    cases_possibles = []
    
    looking = (coordinates[0].index(case[0]),  coordinates[1].index(case[1]))
    looking = (looking[0] + addx, looking[1] + addy)
    stop = False
    while looking[0] >= 0 and looking[1] >= 0 and looking[0] <= 7 and looking[1] <= 7 and not stop :
        
        visee = position[looking[1]][looking[0]] # Pièce présente dans la case que l'on regarde
        
        if visee == "." : # Si la case est vide
            cases_possibles.append(str(coordinates[0][looking[0]] + coordinates[1][looking[1]]))
            
        elif visee[1] == piece[1] : # Si la case contient une piece de même couleur
            stop = True
        
        else : # Si la case contient une piece de couleur oppposée
            cases_possibles.append(str(coordinates[0][looking[0]] + coordinates[1][looking[1]]))
            stop = True
        
        looking = (looking[0] + addx, looking[1] + addy)
        
    return cases_possibles


def cases_possibles(case : str) -> list :
    
    piece = get_piece(case)
    cases_possibles = []
    
    if piece == "." :     # ========== CASE VIDE ========== :
        
        cases_possibles = []
        
        
    elif piece[0] == "p" :     # ========== PION ========== :
        
        if piece[1] == "b": # blanc
            
            if get_piece(str( case[0] + str( int(case[1]) + 1 ) )) == "." : # si la case devant est disponible

                cases_possibles = [ str( case[0] + str( int(case[1]) + 1 ) ) ]

                if case[1] == "2" and get_piece(str( case[0] + str( int(case[1]) + 2 ) )) == "." : # si premier coup (et que l'on peut aller plus loin), on rajoute une case
                    
                    cases_possibles.append(str( case[0] + str( int(case[1]) + 2 ) ))
                
                
        else : # noir
            
            if get_piece(str( case[0] + str( int(case[1]) - 1 ) )) == "." : # si la case devant est disponible

                cases_possibles = [ str( case[0] + str( int(case[1]) - 1 ) ) ]

                if case[1] == "7" and get_piece(str( case[0] + str( int(case[1]) - 2 ) )) == "." : # si premier coup (et que l'on peut aller plus loin), on rajoute une case
                    
                    cases_possibles.append(str( case[0] + str( int(case[1]) - 2 ) ))
        
        
        
    elif piece[0] == "t" :     # ========== TOUR ========== :
        
        # Left
        addx = -1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Right
        addx = 1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Top
        addx = 0
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Bottom
        addx = 0
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        
    elif piece[0] == "c" :     # ========== CAVALIER ========== :
        
        to_check = [[1, 2], [-1, 2], [1, -2], [-1, -2], [2, 1], [2, -1], [-2, 1], [-2, -1]] # x and y relatifs à la pièce que l'on regarde


        # Regarde chaque case de la liste to_check et vérifie si l'on peut y aller
        for i in range(len(to_check)) :

            xplus = to_check[i][0]
            yplus = to_check[i][1]

            x_index = coordinates[0].index(case[0]) + xplus
            y_index = coordinates[1].index(case[1]) + yplus

            visee = position[y_index][x_index] # Pièce présente dans la case que l'on regarde

            if (x_index >= 0 and x_index <= 7 and y_index >= 0 and y_index <= 7) and visee == "." :
                cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
            elif visee[1] != piece[1] :
                cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
        


    elif piece[0] == "f" :     # ========== FOU ========== :
        
        # Bottom-left
        addx = -1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Bottom-Right
        addx = 1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-left
        addx = -1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-right
        addx = 1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        
        
        
    elif piece[0] == "d" :     # ========== DAME ========== :
        # On combine les déplacements du fou et de la tour
        
        # ----- TOUR ----- :
        
        # Left
        addx = -1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Right
        addx = 1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Top
        addx = 0
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Bottom
        addx = 0
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        
        # ----- FOU ----- :
        
        # Bottom-left
        addx = -1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Bottom-Right
        addx = 1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-left
        addx = -1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-right
        addx = 1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        
        
    elif piece[0] == "r" :     # ========== ROI ========== :
        # Même principe que pour le cavalier
        
        to_check = [[-1, 1], [0, 1], [1, 1], [-1, 0], [1, 0], [-1, -1], [0, -1], [1, -1], ] # x and y relatifs à la pièce que l'on regarde
        
        # Regarde chaque case de la liste to_check et vérifie si l'on peut y aller
        for i in range(len(to_check)) :

            xplus = to_check[i][0]
            yplus = to_check[i][1]

            x_index = coordinates[0].index(case[0]) + xplus
            y_index = coordinates[1].index(case[1]) + yplus

            visee = position[y_index][x_index] # Pièce présente dans la case que l'on regarde

            if (x_index >= 0 and x_index <= 7 and y_index >= 0 and y_index <= 7) and visee == "." :
                cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
            elif visee[1] != piece[1] :
                cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
        
    
    return cases_possibles



print("pion noir a7 :", cases_possibles("a7"))

print("pion noir c7 :", cases_possibles("c7"))



















