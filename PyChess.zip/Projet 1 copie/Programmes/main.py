'''
-------------------- PROJET 1 - PyChess --------------------

Bandeau d'informations - tenir à jour !

Version : 11.1 - VERSION FINALE

Dernière édition : Victor, 08/11/2025, 16:40

Commentaires :
    
    - VERSION 11
        - Ajout du tour par tour dans le module move_piece() grâce à la variable globale (pour le bouton nouvelle partie) qui_joue = "blanc" ou qui_joue = "noir"
    - Version 11.1
        - Ajout de 2 boutons :
            - "theme" permet de switcher entre trois thème d'échiquier proposés, gris, vert et marron
            - "points" affiche et masque les points des cases possibles
        - Modification du scipt des couleurs pour le rendre plus polyvalent, réutilisable et compréhensible
        - Correction pour la transparence des points gris : moyenne entre le gris et la couleur de la case
        - Ajout d'un script qui prévient l'utilisateur si il n'a pas installé pygame
        - Plus de commentaires
        - Nouvelle police de caractères, ajoutée dans les fichiers de code

Édition précédente : Kimi, 07/11/2025, 13:48

-------------------------- main.py -------------------------
'''


# -----<===== INITIALISATION =====>-----

# ----- Modules importés -----

try :
    import pygame
except :
    print("Oups, il semblerait que vous n'ayez pas installé Pygame !") # Si l'importation de pygame ne marche pas, c'est que le module n'est pas installé
    
import time      # Si besoin de time.sleep() pour comprendre un bug éventuel
import random


# ----- Couleurs, constantes et initialisation de pygame -----


GREY = (180, 180, 180)
DARK_WHITE = (238, 238, 213)
GREEN = (125, 148, 93)
BG_GREY = (150, 150, 150)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BROWN = (160, 130, 110)


SCALE = 80 # Taille de la fenêtre en %, tout doit être proportionnel - peut être modifié à volonté

WINDOW_LENGHT = SCALE*12
WINDOW_HEIGHT = SCALE*8

WINDOW_SIZE = (WINDOW_LENGHT, WINDOW_HEIGHT)

surface = pygame.display.set_mode(WINDOW_SIZE)
pygame.display.set_caption("PyChess")


# ----- Fonts -----

pygame.font.init()

# Titre (80)
fontbig = pygame.font.Font("LiberationSans-Bold.ttf", int(0.80*SCALE))
txt_chess = fontbig.render("PyChess", True, WHITE)

# Sous-titre (40)
font = pygame.font.Font("LiberationSans-Bold.ttf", int(0.40*SCALE))
txt_tpgame = font.render("Pour 2 joueurs", True, WHITE)

# Boutons (30)
fontsmall = pygame.font.Font("LiberationSans-Bold.ttf", int(0.30*SCALE))
txt_bt1 = fontsmall.render("Nouvelle partie", True, BLACK)
txt_bt2 = fontsmall.render("Changer le thème", True, BLACK)
txt_bt3_a = fontsmall.render("Afficher les points", True, BLACK)
txt_bt3_m = fontsmall.render("Masquer les points", True, BLACK)

# Texte (15)
fonttiny = pygame.font.Font("LiberationSans-Bold.ttf", int(0.15*SCALE))
txt_copyright = fonttiny.render("© KVTeam 2025", True, BLACK)



# ----- Pieces, position et icône de la fenêtre -----


#              A     B     C     D     E     F     G     H
position = [["tn", "cn", "fn", "dn", "rn", "fn", "cn", "tn"], # 8
            ["pn", "pn", "pn", "pn", "pn", "pn", "pn", "pn"], # 7
            [".",  ".",  ".",  ".",  ".",  ".",  ".",  ".", ], # 6
            [".",  ".",  ".",  ".",  ".",  ".",  ".",  ".", ], # 5
            [".",  "." , ".",  ".",  ".",  ".",  ".",  ".", ], # 4
            [".",  ".",  "." , ".",  ".",  ".",  ".",  ".", ], # 3
            ["pb", "pb", "pb", "pb", "pb", "pb", "pb", "pb"], # 2
            ["tb", "cb", "fb", "db", "rb", "fb", "cb", "tb"]] # 1

pn = pygame.transform.scale(pygame.image.load("pieces/pn.png"), (SCALE, SCALE))
cn = pygame.transform.scale(pygame.image.load("pieces/cn.png"), (SCALE, SCALE))
fn = pygame.transform.scale(pygame.image.load("pieces/fn.png"), (SCALE, SCALE))
dn = pygame.transform.scale(pygame.image.load("pieces/dn.png"), (SCALE, SCALE))
rn = pygame.transform.scale(pygame.image.load("pieces/rn.png"), (SCALE, SCALE))
tn = pygame.transform.scale(pygame.image.load("pieces/tn.png"), (SCALE, SCALE))

pb = pygame.transform.scale(pygame.image.load("pieces/pb.png"), (SCALE, SCALE))
cb = pygame.transform.scale(pygame.image.load("pieces/cb.png"), (SCALE, SCALE))
fb = pygame.transform.scale(pygame.image.load("pieces/fb.png"), (SCALE, SCALE))
db = pygame.transform.scale(pygame.image.load("pieces/db.png"), (SCALE, SCALE))
rb = pygame.transform.scale(pygame.image.load("pieces/rb.png"), (SCALE, SCALE))
tb = pygame.transform.scale(pygame.image.load("pieces/tb.png"), (SCALE, SCALE))


# Fait correspondre chaque image à son nom
pieces_images = [[pb, cb, fb, tb, db, rb], [pn, cn, fn, tn, dn, rn]]
pieces_noms = [["pb", "cb", "fb", "tb", "db", "rb"], ["pn", "cn", "fn", "tn", "dn", "rn"]]

# Icône de la fenêtre aléatoire (parmi les 6 différentes pièces blanches)
icon = pygame.image.load("pieces/" + pieces_noms[0][random.randint(0, 5)] +".png")
pygame.display.set_icon(icon)


# ----- Initialisation des variables -----

# Y'a des fois où c'est plus court en anglais ;)

button_selected = ""
piece_en_deplacement = False
piece_selectionnee = "."
old_selection = ""
mouse_pressed = False
qui_joue = "blanc"
theme = 1
theme_changed = False
show_dots = True

coordinates = [["a", "b", "c", "d", "e", "f", "g", "h"], ["8", "7", "6", "5", "4", "3", "2", "1"]] # C'est chelou, mais ça correspond à la matrice de position

peut_roquer = [True, True, True, True] # [Petit roque blanc, grand roque blanc, petit roque noir, grand roque noir]



# -----<===== FONCTIONS PRINCIPALES =====>-----


def get_coord(x : int, y : int) -> str :
    '''Cette fonction renvoie le nom de la case à partir de coordonnées xy (pixels à partir d'en haut à gauche) (str)'''
    
    case = coordinates[0][round(x//(WINDOW_HEIGHT//8))] + coordinates[1][round(y//(WINDOW_HEIGHT//8))]
    return case


def get_place(case : str) -> (int, int):
    '''Cette fonction renvoie la place de la case dans la liste positions (int, int)'''
    
    # place est (colonne, ligne)
    place = (coordinates[0].index(case[0]), coordinates[1].index(case[1])) 
    return place


def get_piece(case : str) -> str :
    '''Cette fonction renvoie la pièce présente dans une case donné (str)'''
    
    # position est position[ligne][colonne]
    place = get_place(case)
    piece = position[place[1]][place[0]]
    return piece




def render() -> None :
    '''render() est la fonction permettant d'afficher l'échiquier, les pièces, les boutons etc dans la fenêtre'''
    
    # Echiquier (cases)
    
    # La variable cc est pour la couleur de case, qui alterne en gros entre col1 et col2
    
    pp = []
    if old_selection != "":
        pp = cases_possibles(old_selection)
    
    cc = 0
    
    if theme == 1 : # Définition des couleurs de cases en fonction du thème
        col1 = WHITE
        col2 = GREY
    elif theme == 2 :
        col1 = DARK_WHITE
        col2 = GREEN
    else :
        col1 = DARK_WHITE
        col2 = BROWN
    
    col1bis = (col1[0]-45, col1[1]-45, col1[2])
    col2bis = (col2[0]-60, col2[1]-60, col2[2]+10) # On accentue plus le bleu sur la case foncée
    
    
    for j in range(0, WINDOW_HEIGHT, WINDOW_HEIGHT//8):
        for i in range(0, WINDOW_HEIGHT, WINDOW_HEIGHT//8):
            if old_selection != "" : # Pour surligner la case (en bleu) où se trouve la pièce qui va bouger
                if get_place(old_selection) == get_place(get_coord(i, j)) : 
                    if cc == 1 :
                        color = col2bis
                        cc = 0
                    else :
                        color = col1bis
                        cc = 1
                else :
                    if cc == 1 :
                        color = col2
                        cc = 0
                    else :
                        color = col1
                        cc = 1
            else :
                
                if selection != "" : # Pour surligner la case 
                    if get_place(selection) == get_place(get_coord(i, j)): 
                        if cc == 1 :
                            color = (col2[0], col2[1], col2[2]-50)
                            cc = 0
                        else :
                            color = (col1[0], col1[1], col1[2]-50)
                            cc = 1
                    else :
                        if cc == 1 :
                            color = col2
                            cc = 0
                        else :
                            color = col1
                            cc = 1
                else :
                    if cc == 1 :
                        color = col2
                        cc = 0
                    else :
                        color = col1
                        cc = 1
            
            pygame.draw.rect(surface, color, ((i, j), (WINDOW_HEIGHT//8, WINDOW_HEIGHT//8)))
            
            dot_color = (((color[0]+BG_GREY[0]*3)/4), ((color[1]+BG_GREY[1]*3)/4), ((color[2]+BG_GREY[2]*3)/4))
            
            if get_coord(i, j) in pp and show_dots :
                if get_piece(get_coord(i, j)) != "." :
                    pygame.draw.circle(surface, dot_color, (i + WINDOW_HEIGHT//16, j + WINDOW_HEIGHT//16), 0.5*SCALE, int(0.1*SCALE))
                else :
                    pygame.draw.circle(surface, dot_color, (i + WINDOW_HEIGHT//16, j + WINDOW_HEIGHT//16), 0.15*SCALE)
        
        
        cc = (cc-1)*-1 # Inverse cc entre deux rangées

    
    
    # Pieces
    
    i=0
    for y in range(0, WINDOW_HEIGHT, WINDOW_HEIGHT//8):
        for x in range(0, WINDOW_HEIGHT, WINDOW_HEIGHT//8):

            piece = position[(i-(i%8))//8][i%8]
            
            if not piece == "." :
                
                if piece[1] == "b":
                    piece_img = pieces_images[0][pieces_noms[0].index(piece)]
                else :
                    piece_img = pieces_images[1][pieces_noms[1].index(piece)]
                
                surface.blit(piece_img, (x-1, y))
                
            i += 1
    
    
    # Panneau
    
    pygame.draw.rect(surface, (200, 200, 200), (8.30*SCALE, 2*SCALE, 3.4*SCALE, 3*SCALE))
    
    
    # Texte
    
    surface.blit(txt_chess, (8.35*SCALE, 0.20*SCALE))
    surface.blit(txt_tpgame, (8.6*SCALE, 1.20*SCALE))
    surface.blit(txt_copyright, (10.7*SCALE, 7.7*SCALE))
    
    
    # Boutons
    
    # Nouvelle partie
    
    if button_selected == "nv partie" :
        pygame.draw.rect(surface, WHITE, (8.30*SCALE, 2*SCALE, 3.4*SCALE, 1*SCALE))
        surface.blit(txt_bt1, (8.9*SCALE, 2.33*SCALE))
    else :
        surface.blit(txt_bt1, (8.9*SCALE, 2.33*SCALE))
    
    
    # Changer le thème
    
    noms_themes = ["Argenté", "Verdure", "Bois"]
    if button_selected == "theme" :
        pygame.draw.rect(surface, WHITE, (8.30*SCALE, 3*SCALE, 3.4*SCALE, 1*SCALE))
        surface.blit(txt_bt2, (8.7*SCALE, 3.22*SCALE))
        desc = fonttiny.render("Thème actuel : " + noms_themes[theme-1], True, BLACK)
        surface.blit(desc, (9.1*SCALE, 3.6*SCALE))
    else :
        surface.blit(txt_bt2, (8.7*SCALE, 3.22*SCALE))
        desc = fonttiny.render("Thème actuel : " + noms_themes[theme-1], True, BLACK)
        surface.blit(desc, (9.1*SCALE, 3.6*SCALE))
    
    
    # Afficher/masquer les points
    
    if button_selected == "points" :
        pygame.draw.rect(surface, WHITE, (8.30*SCALE, 4*SCALE, 3.4*SCALE, 1*SCALE))
        if show_dots :
            surface.blit(txt_bt3_m, (8.65*SCALE, 4.32*SCALE))
        else :
            surface.blit(txt_bt3_a, (8.7*SCALE, 4.32*SCALE))
    else :
        if show_dots :
            surface.blit(txt_bt3_m, (8.65*SCALE, 4.32*SCALE))
        else :
            surface.blit(txt_bt3_a, (8.7*SCALE, 4.32*SCALE))



def on_board() -> bool :
    '''Renvoie True si la souris est sur l'échiquier, False sinon'''
    
    # Correction : réutiliser la même logique que dans update
    
    mx, my = pygame.mouse.get_pos()
    
    # Vérifie si la souris est dans les limites du plateau (taille WINDOW_HEIGHT x WINDOW_HEIGHT)
    if mx < 1 or mx >= WINDOW_HEIGHT  or my < 1 or my > WINDOW_HEIGHT - 2 :
        return False
    else :
        return True


def click() -> bool :
    '''renvoie True si on clique gauche, sinon False'''
    
    click_state = pygame.mouse.get_pressed()[0] 
    return click_state



def update() -> None :
    '''Update() contient les calculs à faire chaque frame (avant affichage), comme la détection et les effets des boutons ou la position de la souris'''
    
    # Position de la souris sur l'échiquier
    # Variable mousepos : en dehors de la fenêtre : "out", sur l'échiquier : coordonnées (genre d4), côté boutons : "panel"    -> str
    # on_board est vraie quand la souris est sur l'échiquier
    
    mx, my = pygame.mouse.get_pos()
    if mx < 1 or mx > WINDOW_LENGHT - 2  or my < 1 or my > WINDOW_HEIGHT - 2 :
        mousepos = "out"
        on_board_state = False
    elif mx > WINDOW_HEIGHT -1 :
        mousepos = "panel"
        on_board_state = False
    else :
        mousepos = get_coord(mx, my)
        on_board_state = True
        
    
    global button_selected
    global theme
    global theme_changed

    if mx >= 8.30*SCALE and my >= 2*SCALE and mx <= 11.70*SCALE and my <= 3*SCALE : # BOUTON NOUVELLE PARTIE
        button_selected = "nv partie"
        if click() :
            # Ici, effets du bouton
            
            # Position de départ
            global position
            #              A     B     C     D     E     F     G     H
            position = [["tn", "cn", "fn", "dn", "rn", "fn", "cn", "tn"], # 8
                        ["pn", "pn", "pn", "pn", "pn", "pn", "pn", "pn"], # 7
                        [".",  ".",  ".",  ".",  ".",  ".",  ".",  ".", ], # 6
                        [".",  ".",  ".",  ".",  ".",  ".",  ".",  ".", ], # 5
                        [".",  "." , ".",  ".",  ".",  ".",  ".",  ".", ], # 4
                        [".",  ".",  "." , ".",  ".",  ".",  ".",  ".", ], # 3
                        ["pb", "pb", "pb", "pb", "pb", "pb", "pb", "pb"], # 2
                        ["tb", "cb", "fb", "db", "rb", "fb", "cb", "tb"]] # 1
            
            global old_selection 
            old_selection = ""
            global piece_en_deplacement
            piece_en_deplacement = False
            global peut_roquer
            peut_roquer = [True, True, True, True]
            global qui_joue
            qui_joue = "blanc"
            
    elif button_selected == "nv partie" :
        button_selected = ""
    
    if mx >= 8.30*SCALE and my >= 3*SCALE and mx <= 11.70*SCALE and my <= 4*SCALE : # BOUTON DE ROTATION DE L'ÉCHIQUIER
        button_selected = "theme"
        if click() :
            # Ici, effets du bouton
            
            if not theme_changed :
                if theme == 3 :
                    theme = 1
                    theme_changed = True
                else :
                    theme += 1
                    theme_changed = True
                
        else :
            theme_changed = False
                
    elif button_selected == "theme" :
        button_selected = ""
    
    if mx >= 8.30*SCALE and my >= 4*SCALE and mx <= 11.70*SCALE and my <= 5*SCALE : # BOUTON D'AFFICHAGE OU DE MASQUAGE DES POINTS DE CASES POSSIBLES
        button_selected = "points"
        if click() :
            # Ici, effets du bouton
            
            global show_dots
            global dots_changed
            
            if not dots_changed :
                if show_dots :
                    show_dots = False
                    dots_changed = True
                else :
                    show_dots = True
                    dots_changed = True
                
        else :
            dots_changed = False
                
    elif button_selected == "points" :
        button_selected = ""
    
    
    
    # selectionne la case survolée quand on clique, sinon, pas de selection

    global selection
    selection = ""
    
    
    if click() and on_board_state : # Utilisation de click() pour appeler la fonction et de on_board_state pour l'état
        selection = mousepos




def move_piece() -> None :
    '''Cette fonction, similaire à update, permet de gérer les déplacements des pièces sur le plateau.'''
    
    global piece_selectionnee
    global piece_en_deplacement
    global mouse_pressed
    global old_selection
    global qui_joue
    blanc = ["pb", "cb", "fb", "tb", "db", "rb"]
    noir = ["pn", "cn", "fn", "tn", "dn", "rn"]
    
    # Limite les déplacements dans les cases possibles de déplacement de la pièce aux échecs
    
    cp = []
    if old_selection != "":
        cp = cases_possibles(old_selection)
    
    # Gère les deplacements avec un click unique
        
    if click() and on_board():
        if not mouse_pressed :
            place = get_place(selection)
            piece = get_piece(selection)
            x = place[0]
            y = place[1]
            
            if piece_en_deplacement :
                    
                if get_place(old_selection) != get_place(selection) and selection in cp :
                    
                    if old_selection != "" :
                        
                        # Promotion en dame du pion
                        if piece_selectionnee[0] == "p" :
                            if (piece_selectionnee[1] == "b" and y == 0) or (piece_selectionnee[1] == "n" and y == 7) :
                                piece_selectionnee = "d" + piece_selectionnee[1]
                    
                        # Roque
                        
                        if piece_selectionnee == "rb" :
                            if old_selection == "e1" :
                                if selection == "g1" :
                                    position[7][7] = "."
                                    position[7][5] = "tb"
                                if selection == "c1" :
                                    position[7][0] = "."
                                    position[7][3] = "tb"
                            peut_roquer[0] = False
                            peut_roquer[1] = False
                        
                        if piece_selectionnee == "rn" :
                            if old_selection == "e8" :
                                if selection == "g8" :
                                    position[0][7] = "."
                                    position[0][5] = "tn"
                                if selection == "c8" :
                                    position[0][0] = "."
                                    position[0][3] = "tn"
                            peut_roquer[2] = False
                            peut_roquer[3] = False
                        
                        
                        if piece_selectionnee == "tb" :
                            if old_selection == "h1" :
                                peut_roquer[0] = False
                            elif old_selection == "a1" :
                                peut_roquer[1] = False
                        
                        if piece_selectionnee == "tn" :
                            if old_selection == "h8" :
                                peut_roquer[2] = False
                            elif old_selection == "a8" :
                                peut_roquer[3] = False
                    
                        old_place = get_place(old_selection)
                        old_x = old_place[0]
                        old_y = old_place[1]
                        position[old_y][old_x] = "." 
                        old_selection = ""
                    
                    # Déplacement de la piece selectionnée
                    
                    position[y][x] = piece_selectionnee 
                    piece_en_deplacement = False 
                    piece_selectionnee = ""
                    
                    # Tour par tour
                    if qui_joue == "blanc" : 
                        qui_joue = "noir"
                    elif qui_joue == "noir" :
                        qui_joue = "blanc"
                        
                else : # Déselection de la pièce selectionnée (si on clique sur une case non possible)
                    old_selection = ""
                    piece_en_deplacement = False 
                    piece_selectionnee = ""
                
            # Sélection de la pièce blanche
            
            elif not piece_en_deplacement and piece in blanc and qui_joue == "blanc" :
                piece_en_deplacement = True
                piece_selectionnee = piece
                old_selection = selection
            
            # Sélection de la pièce noire
            
            elif not piece_en_deplacement and piece in noir and qui_joue == "noir" :
                piece_en_deplacement = True
                piece_selectionnee = piece
                old_selection = selection
                
            
            
        mouse_pressed = True
    else:
        mouse_pressed = False
    
    




# ---------- POSITIONS POSSIBLES ----------


def check_line(case : str, addx : int, addy : int) -> list :
    ''' Fonction utilisée par cases_possibles pour optimiser le code.
        Elle renvoie la liste de toutes les cases (str) en partant de la case de départ et en ajoutant addx et addy (int) jusqu'au bord ou jusqu'à une pièce,
        inclue si de couleur opposée.'''
    
    piece = get_piece(case)
    cases_possibles = []
    
    looking = (coordinates[0].index(case[0]),  coordinates[1].index(case[1]))
    looking = (looking[0] + addx, looking[1] + addy)
    stop = False
    while looking[0] >= 0 and looking[1] >= 0 and looking[0] <= 7 and looking[1] <= 7 and not stop :
        
        visee = position[looking[1]][looking[0]] # Pièce présente dans la case que l'on regarde
        
        if visee == "." : # Si la case est vide
            cases_possibles.append(str(coordinates[0][looking[0]] + coordinates[1][looking[1]]))
            
        elif visee[1] == piece[1] : # Si la case contient une piece de même couleur
            stop = True
        
        else : # Si la case contient une piece de couleur oppposée
            cases_possibles.append(str(coordinates[0][looking[0]] + coordinates[1][looking[1]]))
            stop = True
        
        looking = (looking[0] + addx, looking[1] + addy)
        
    return cases_possibles


def cases_possibles(case : str) -> list :
    ''' Cette fonction prend en entrée les coordonnées d'une case (str) et, si une pièce y est présente,
        renvoie la liste des cases (str) où elle peut aller, sinon elle renvoie une liste vide.'''
    
    piece = get_piece(case)
    cases_possibles = []
    
    if piece == "." :     # ========== CASE VIDE ========== :
        
        cases_possibles = []
        
        
    elif piece[0] == "p" :     # ========== PION ========== :
        
        if piece[1] == "b": # blanc
            
            if get_piece(str( case[0] + str( int(case[1]) + 1 ) )) == "." : # si la case devant est disponible

                cases_possibles = [ str( case[0] + str( int(case[1]) + 1 ) ) ]

                if case[1] == "2" and get_piece(str( case[0] + str( int(case[1]) + 2 ) )) == "." : # si premier coup (et que l'on peut aller plus loin), on rajoute une case
                    
                    cases_possibles.append(str( case[0] + str( int(case[1]) + 2 ) ))
            
            # PRISE
            
            # Même principe que pour le cavalier
        
            to_check = [[-1, -1], [1, -1]] # x and y relatifs à la pièce que l'on regarde
        
            # Regarde chaque case de la liste to_check et vérifie si l'on peut y aller
            for i in range(len(to_check)) :

                xplus = to_check[i][0]
                yplus = to_check[i][1]

                x_index = coordinates[0].index(case[0]) + xplus
                y_index = coordinates[1].index(case[1]) + yplus
                
                if (x_index >= 0 and x_index <= 7 and y_index >= 0 and y_index <= 7) :
                    visee = position[y_index][x_index] # Pièce présente dans la case que l'on regarde
                    if visee != "." :
                        if visee[1] != piece[1] :
                          cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
            
            
                
                
        else : # noir
            
            if get_piece(str( case[0] + str( int(case[1]) - 1 ) )) == "." : # si la case devant est disponible

                cases_possibles = [ str( case[0] + str( int(case[1]) - 1 ) ) ]

                if case[1] == "7" and get_piece(str( case[0] + str( int(case[1]) - 2 ) )) == "." : # si premier coup (et que l'on peut aller plus loin), on rajoute une case
                    
                    cases_possibles.append(str( case[0] + str( int(case[1]) - 2 ) ))
            
            
            # PRISE
            
            to_check = [[-1, 1], [1, 1]] # x and y relatifs à la pièce que l'on regarde

            # Regarde chaque case de la liste to_check et vérifie si l'on peut y aller
            for i in range(len(to_check)) :

                xplus = to_check[i][0]
                yplus = to_check[i][1]

                x_index = coordinates[0].index(case[0]) + xplus
                y_index = coordinates[1].index(case[1]) + yplus
                
                if (x_index >= 0 and x_index <= 7 and y_index >= 0 and y_index <= 7) :
                    visee = position[y_index][x_index] # Pièce présente dans la case que l'on regarde
                    if visee != "." :
                        if visee[1] != piece[1] :
                          cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
                        
                        
            
            
        
        
    elif piece[0] == "t" :     # ========== TOUR ========== :
        
        # Left
        addx = -1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Right
        addx = 1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Top
        addx = 0
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Bottom
        addx = 0
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        
    elif piece[0] == "c" :     # ========== CAVALIER ========== :
        
        to_check = [[1, 2], [-1, 2], [1, -2], [-1, -2], [2, 1], [2, -1], [-2, 1], [-2, -1]] # x and y relatifs à la pièce que l'on regarde


        # Regarde chaque case de la liste to_check et vérifie si l'on peut y aller
        for i in range(len(to_check)) :

            xplus = to_check[i][0]
            yplus = to_check[i][1]

            x_index = coordinates[0].index(case[0]) + xplus
            y_index = coordinates[1].index(case[1]) + yplus

            if (x_index >= 0 and x_index <= 7 and y_index >= 0 and y_index <= 7) :
                visee = position[y_index][x_index] # Pièce présente dans la case que l'on regarde
                if visee == "." :
                    cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
                elif visee[1] != piece[1] :
                    cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
        


    elif piece[0] == "f" :     # ========== FOU ========== :
        
        # Bottom-left
        addx = -1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Bottom-Right
        addx = 1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-left
        addx = -1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-right
        addx = 1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        
        
        
    elif piece[0] == "d" :     # ========== DAME ========== :
        # On combine les déplacements du fou et de la tour
        
        # ----- TOUR ----- :
        
        # Left
        addx = -1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Right
        addx = 1
        addy = 0
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Top
        addx = 0
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        # Bottom
        addx = 0
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        
        # ----- FOU ----- :
        
        # Bottom-left
        addx = -1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Bottom-Right
        addx = 1
        addy = 1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-left
        addx = -1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
            
        # Top-right
        addx = 1
        addy = -1
        
        cases_possibles.extend(check_line(case, addx, addy))
        
        
        
    elif piece[0] == "r" :     # ========== ROI ========== :
        # Même principe que pour le cavalier
        
        to_check = [[-1, 1], [0, 1], [1, 1], [-1, 0], [1, 0], [-1, -1], [0, -1], [1, -1]] # x and y relatifs à la pièce que l'on regarde
        
        # Regarde chaque case de la liste to_check et vérifie si l'on peut y aller
        for i in range(len(to_check)) :

            xplus = to_check[i][0]
            yplus = to_check[i][1]

            x_index = coordinates[0].index(case[0]) + xplus
            y_index = coordinates[1].index(case[1]) + yplus

            if (x_index >= 0 and x_index <= 7 and y_index >= 0 and y_index <= 7) :
                visee = position[y_index][x_index] # Pièce présente dans la case que l'on regarde
                if visee == "." :
                    cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
                elif visee[1] != piece[1] :
                    cases_possibles.append(str( coordinates[0][x_index] + coordinates[1][y_index] ))
        
        
        # ===== ROQUE=====
        
        # --- Blancs ---
        
        if case == "e1" :
            # Petit roque
            if get_piece("f1") == "." and get_piece("g1") == "." and get_piece("h1") == "tb" and peut_roquer[0] :
                cases_possibles.append("g1")
            
            # Grand roque
            if get_piece("d1") == "." and get_piece("c1") == "." and get_piece("b1") == "." and get_piece("a1") == "tb" and peut_roquer[1] :
                cases_possibles.append("c1")
        
        # --- Noirs ---
        
        if case == "e8" :
            # Petit roque
            if get_piece("f8") == "." and get_piece("g8") == "." and get_piece("h8") == "tn" and peut_roquer[2] :
                cases_possibles.append("g8")
            
            # Grand roque
            if get_piece("d8") == "." and get_piece("c8") == "." and get_piece("b8") == "." and get_piece("a8") == "tn" and peut_roquer[3] :
                cases_possibles.append("c8")
        
        
        
        
    return cases_possibles




# ===== Ne marche pas - trop complexe - abandonné par manque de temps =====

def controle(case : str, color : str) -> bool :
    '''Cette fonction prend en entrée une case (str) et une couleur de pièces, 'b' ou 'n', et renvoie True si cette case est menacée par une pièce adverse'''
    
    result = False
    piece = get_piece(case)
    
    if piece != "." :
        if piece[1] != color : # Vérifie qu'il n'y a pas de pièce adverse sur la case
            # Vérifie chaque case, si on croise une pièce adverse on regarde si elle contrôle la case
            for i in range(8) :
                for j in range(8) :
                    
                    if position[j][i] != "." :
                        if position[j][i][1] == color : # Quand on trouve une pièce adverse
                            if case in cases_possibles(coordinates[0][i] + coordinates[1][j]) :
                                result = True


    return result

def remove_checked(case : str, cases : list) -> list :
    '''Prend en entrée la case du roi à contrôler et la liste de ses positions possibles et renvoie cette même liste après avoir enlevé les case interdites'''
    
    piece = get_piece(case)
    i=0
    while i < len(cases) :
        if controle(cases[i], piece[1]) :
            cases.pop(i)
            i -= 1
        i += 1
    print(controle("e6", "b"))
    return cases









# -----<===== BOUCLE PRINCIPALE =====>-----


running = True



while running == True : # Toutes les frames :
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT: # Quand on ferme la fenêtre, mettre fin à la boucle principale while puis quitter pygame
            running = False
    
    # Pas de paramètres nécessaires grâce à 'global'
    
    update() # Mise à jour

    move_piece() # Déplacement des pièces
    
    
    surface.fill(BG_GREY) # Arrière-plan basique
    
    render() # Affichage
    
    pygame.display.flip() # Actualise l'affichage
    
    
    #print(controle("e8", "b"))
    #print(piece_selectionnee)
    #print(piece_en_deplacement)
    #print(old_selection)
    #print(selection)
    
pygame.quit()




